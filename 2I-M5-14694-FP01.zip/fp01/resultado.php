<?php
    $nome = $_POST["nome"];
    $idade = $_POST["idade"];
    $senha = $_POST["senha"];
    $tamanho = strlen($senha);
    
    echo "Olá, $nome! Seja bem-vindo.";

    if ($idade < 12) {
        echo "<p>Classificação: Criança</p>";
    } 
    elseif ($idade >= 12 && $idade <= 17) {
        echo "<p>Classificação: Adolescente</p>";   
    } 
    else {
        echo "<p>Classificação: Adulto</p>";
    }

    if ($tamanho < 5) {
        echo '<p>Nível: <span style="color: red;">Password fraca</span></p>';
    } 
    elseif ($tamanho >= 5 && $tamanho <= 8) {
        echo '<p>Nível: <span style="color: orange;">Password média</span></p>';
    } 
    else {
        echo '<p>Nível: <span style="color: green;">Password forte</span></p>';
    }
?>